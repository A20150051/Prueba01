document.write("<h1>Bienvenido a la página de JavaScript</h1>");
var non - prompt("Ingrese su nombre");
document write(
    "<h1>Hola" + non + "es tu primer contacto con la programación en JavaScript</h1>");
